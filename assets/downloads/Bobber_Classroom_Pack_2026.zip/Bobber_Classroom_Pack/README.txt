Bobber the Water Safety Dog — Classroom Pack
U.S. Army Corps of Engineers, Tulsa District
Built by the SWOSU student team credited on the website.

Included:
- PFD lesson outline
- Bobber's Golden Rules lesson
- Bobber Activity Book
- Bookmarks
- Life-jacket coloring sheet
- Water Safety Resource Guide
- English and Spanish QR codes for the website

Website: https://usaceswosu.github.io/Tulsa-District-Water-Safety-Web-Platform/
Spanish: https://usaceswosu.github.io/Tulsa-District-Water-Safety-Web-Platform/?lang=es
QR poster: https://usaceswosu.github.io/Tulsa-District-Water-Safety-Web-Platform/poster.html
Accessibility and privacy: https://usaceswosu.github.io/Tulsa-District-Water-Safety-Web-Platform/accessibility.html

Print the PDFs at 100% / actual size. The website has the full library of posters,
coloring sheets, storybooks, and the printable Safety Hero certificate.

These are official USACE program materials; check the Bobber program page for updates.
